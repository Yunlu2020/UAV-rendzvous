n=[10,50,100,250,500];
a=3;
Aver_D=aver_D(:);
[x,flag]=sort(Aver_D);
T_graph=zeros(6,100);
for i=1:6
    for j=1:5
        T_graph(i,(j-1)*100+1:j*100)=t(j,:,i);
    end
end
for i=1:6
    T_graph(i,:)=T_graph(i,flag);
    %T_graph(i,:)=t(a,flag,i);
end
hold on
plot(x,T_graph(1,:),'color','c','LineWidth',1);
plot(x,T_graph(2,:),'color','r','LineWidth',1);
plot(x,T_graph(3,:),'color','b','LineWidth',1);
plot(x,T_graph(4,:),'color','g','LineWidth',1);
plot(x,T_graph(5,:),'color','y','LineWidth',1);
plot(x,T_graph(6,:),'color','m','LineWidth',1);
hl=legend('MAC','MRAC','SJRW','PMTP','ABIO','FLOOD');
set(hl,'Orientation','horizon');
set(gca,'YMinorTick','off'); 
set(gca,'YTick',[10^1,10^2,10^3,10^4,10^5,10^6]);
set(gca,'XGrid','on'); 
set(gca,'YGrid','on'); 
set(gca,'YMinorGrid','off'); 
%set(gca,'XTick',n);
set(gca,'yscale','log');
%axis([0,15,1,1000000]);
xlabel('average degree');
ylabel('TTR');