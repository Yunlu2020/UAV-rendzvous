M=30;
%MΪ��ѡ����ŵ���
m=2;
%mΪMRAC�㷨�����˻��ϰ�װ�����ߵ�̨��
% A_aver=zeros(100,100,1000);
% %�������1000���ڵ���Ϊ100������
% for i=1:1000
%     A_aver(:,:,i)=creat_graph(100);
% end
% t_averD=zeros(6,1000);
% for j=1:1000
%     A=A_aver(:,:,j);
%     [t_averD(1,j),c]=mac(A);
%     [t_averD(2,j),c]=mrac_opt(A,m);
%     [t_averD(3,j),c]=sjrw(A,M);
%     [t_averD(4,j),c]=P_MTPA(A,M);
%     [t_averD(5,j),c]=abio(A,M);
%     [t_averD(6,j),c]=fl_opt(A);
%     display([num2str(j/10),'%']);
% end
Aver_D=zeros(1,1000);
for j=1:1000
    Aver_D(j)=sum(sum(A_aver(:,:,j)))/100;
end
%Aver_D=aver_D(a,:);
[x,flag]=sort(Aver_D);
T_graph=zeros(6,1000);
% for i=1:6
%     for j=1:5
%         T_graph(i,(j-1)*100+1:j*100)=t(j,:,i);
%     end
% end
for i=1:6
    %T_graph(i,:)=T_graph(i,flag);
    T_graph(i,:)=t_averD(i,flag);
end
hold on
plot(x,T_graph(1,:),'color','c','LineWidth',1);
plot(x,T_graph(2,:),'color','r','LineWidth',1);
% plot(x,T_graph(3,:),'color','b','LineWidth',1);
% plot(x,T_graph(4,:),'color','g','LineWidth',1);
% plot(x,T_graph(5,:),'color','y','LineWidth',1);
plot(x,T_graph(6,:),'color','m','LineWidth',1);
%hl=legend('MAC','MRAC','SJRW','PMTP','ABIO','FLOOD');
hl=legend('MAC','MRAC','FLOOD');
set(hl,'Orientation','horizon');
set(gca,'YMinorTick','off'); 
%set(gca,'YTick',[10^1,10^2,10^3]);
%set(gca,'YTick',[10^1,10^2,10^3,10^4,10^5,10^6]);
set(gca,'XGrid','on'); 
set(gca,'YGrid','on'); 
set(gca,'YMinorGrid','off'); 
%set(gca,'XTick',n);
%set(gca,'yscale','log');
axis([4,15,0,250]);
%axis([4,15,1,100000]);
xlabel('average degree');
ylabel('TTR');