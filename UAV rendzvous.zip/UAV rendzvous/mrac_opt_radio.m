x=2:66;
hold on;
plot(x,mean_mrac_radio_10(1:65),'b-*','LineWidth',1);
y=ones(65)*(mean(t_fl_opt(3,:)));
plot(x,y,'--r','LineWidth',1);
legend('MRAC','FLOOD');
set(gca,'XGrid','on'); 
set(gca,'YGrid','on'); 
xlabel('the number of radios');
ylabel('ATTR');
%axes('Position',[40,60,9.55,9.85]);
%text(X(1),Y(1),'(1.8660��2.7321)','FontSize',12)
