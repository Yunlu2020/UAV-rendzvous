% cdf=cell(5,5);
% for i=1:5
%     for j=1:5
%         cdf{i,j}=ones(1,t_max_P_MTP(j));
%         cdf{i,j}(1:length(cdf_mean_graph{i,j}))=cdf_mean_graph{i,j};
%     end
% end
hold on;
i=4;
%����cdf��ʱ��仯������
x=1:length(cdf{1,i});
plot(x,cdf{1,i},'r','LineWidth',1);
plot(x,cdf{2,i},'y','LineWidth',1);
plot(x,cdf{3,i},'g','LineWidth',1);
plot(x,cdf{4,i},'b','LineWidth',1);
plot(x,cdf{5,i},'c','LineWidth',1);
plot(x,cdf_P_MTP{i},'m','LineWidth',1);
legend('MAC','SJRW','ABIO','FLOOD','FAC','PMTP');
set(gca,'xscale','log');
%set(gca,'XMinorTick','off'); 
set(gca,'XTick',[10^0,10^1,10^2,10^3,10^4,10^5]);
set(gca,'XGrid','on'); 
set(gca,'YGrid','on'); 
set(gca,'XMinorGrid','off'); 
xlabel('TTR');
ylabel('CDF');
% hold on;
% i=1;
% %����cdf��ʱ��仯������
% x=1:length(cdf_mean_graph{1,i});
% plot(x,cdf_mean_graph{1,i},'color','r','LineWidth',1);
% plot(x,cdf_mean_graph{2,i},'color','y','LineWidth',1);
% plot(x,cdf_mean_graph{3,i},'color','g','LineWidth',1);
% plot(x,cdf_mean_graph{4,i},'color','b','LineWidth',1);
% plot(x,cdf_mean_graph{5,i},'color','c','LineWidth',1);
% plot(x,cdf_P_MTP{i},'color','m','LineWidth',1);
% legend('MAC','SJRW','ABIO','FLOOD','FAC','P_MTP');
% set(gca,'xscale','log');
% xlabel('TTR');
% ylabel('CDF');
%filename=['the CDF of consistent nodes when m=' num2str(n(i)) 'update'];
%saveas(gcf,filename,'fig');