F_=zeros(6,50);
num=0;
for i=1:50
    for j=1:6
        F_(j,i)=(F(j,i)-F_center(i))/3;
    end
end
correct=zeros(1,589);
x1=zeros(1,589);
error=zeros(1,11);
x2=zeros(1,11);
index1=1;
index2=1;
for i=1:6
    for j=1:50
        if abs(F_(i,j))<0.5
            correct(index1)=F_(i,j);
            x1(index1)=j;
            index1=index1+1;
        else
            error(index2)=F_(i,j);
            x2(index2)=j;
            index2=index2+1;
        end
    end
end
hold on;
% for i=1:6
%     for j=1:50
%         if abs(F_(i,j))<0.5
%             scatter(j,F_(i,j),[],'k','o');
%         else
%             num=num+1;
%             scatter(j,F_(i,j),[],'k','x');
%         end
%     end
% end
% legend('right node','error node');
scatter(x1,correct,[],'g','o','filled','MarkerEdgeColor',[0.3 0.3 0.3]);
scatter(x2,error,[],'r','o','filled','MarkerEdgeColor',[0.3 0.3 0.3]);
legend('correct node','error node');
%ggplotAxes2D([],'ColorOrder','Set2','EdgeStyle','gray');
x=1:50;y=ones(50)*(-0.5);
plot(x,y,'--k','LineWidth',2);
x=1:50;y=ones(50)*(0.5);
plot(x,y,'--k','LineWidth',2);
set(gca,'XGrid','on'); 
set(gca,'YGrid','on'); 
xlabel('Experiment serial number');
ylabel('PCF');
%scatter(x,F_(1,:),[],c);
% scatter(x,F_(2,:),[],c(2,:));
% scatter(x,F_(3,:),[],c(3,:));
% scatter(x,F_(4,:),[],c(4,:));
% scatter(x,F_(5,:),[],c(5,:));
% scatter(x,F_(6,:),[],c(6,:));
hold off;