temp=t_opt(:,4:5);
s=7;
bar(n(4:5),temp.');
legend('FLOOD','FTCM','SJRW','ABIO','FL_IMPRO');
%set(gca,'XTickLabel',{'10','50','100'})
xlabel('Varying the value of N');
ylabel('ATTR');
%axis([-20 120 0 3200]); 
for i = 1:2
    text(n(i+3)-80,temp(1,i),num2str(temp(1,i)),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',s);
    text(n(i+3)-40,temp(2,i),num2str(temp(2,i)),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',s);
    text(n(i+3),temp(3,i),num2str(temp(3,i)),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',s);
    text(n(i+3)+40,temp(4,i),num2str(temp(4,i)),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',s);
    text(n(i+3)+80,temp(5,i),num2str(temp(5,i)),'HorizontalAlignment','center','VerticalAlignment','bottom','FontSize',s);
end
