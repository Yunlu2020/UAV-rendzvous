% function  S = CreateNode(DEF)

DEF=5;
connect=6;

L=rand(DEF);
L=10*L;
L=floor(L);
L=mod(L,2);

for i=1:DEF
    k=0;
    for j=1:DEF
        if L(i,j)==0
            L(i,j)=inf;
        end
      
        if L(i,j)==1
            k=k+1;
            if k>connect
                L(i,j)=inf;
%             else if k==0
%                     L(i,j)=1;
%                 end
                
            end
        end
        L(j,i)=L(i,j);
    end
end
for i=1:DEF
    L(i,i)=0;
end

S=zeros(length(L));
for i=1:length(L)
    for j=1:length(L)
        S(i,j)=dijkstra( L,i,j );
    end
end
S


% end


