CC=zeros(5,3);
%type='Spearman';
type='pearson';
for i=1:5
    T=iter_mac(i,:)';
    CC(i,1)=corr(T,D(i,:)'     , 'type' , type);
    CC(i,2)=corr(T,aver_D(i,:)', 'type' , type);
    CC(i,3)=corr(T,assort(i,:)', 'type' , type);
end
hold on;
%figure('color','w');
bar(CC);
hl=legend('diameter','average degree','assortativity');
set(hl,'Orientation','horizon');
set(gca,'XTickLabel',{'10','50','100','250','500'});
xlabel('the number of nodes');
ylabel('correlation coefficient');
set(gca,'XGrid','on');
set(gca,'YGrid','on');
%axis([0,5,0,1.1]);
