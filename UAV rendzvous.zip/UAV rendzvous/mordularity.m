function [Q]=mordularity(A)
N=length(A);
degree=sum(A);
a=degree./sum(degree);
e=A./sum(degree);
Q_=zeros(N,N);
%��������
community=zeros(1,N);
%���ڵ�����������
A_=A;
%������¼������֮����������
Q=0;
for i=1:N
    community(i)=i;
    for j=1:N
        if(A(i,j)==1)
            Q_(i,j)=e(i,j)-a(i)*a(j);
        end
    end
end
while ~isempty(find(Q_>0, 1))
    [I,J]=find(Q_==max(max(Q_)));
    i=I(1);
    j=J(1);
    community(i)=j;
    temp=Q_(i,:);
    Q_(i,:)=zeros(1,N);
    Q_(:,i)=zeros(N,1);%ɾ����i�к͵�i��
    for k=1:N
        if(A_(k,j)==1&&A_(k,i)==1&&k~=j)
            Q_(j,k)=temp(k)+Q_(j,k);
            Q_(k,j)=temp(k)+Q_(k,j);
        elseif(A_(k,j)~=1&&A_(k,i)==1&&k~=j)
            Q_(j,k)=temp(k)-2*a(j)*a(k);
            Q_(k,j)=temp(k)-2*a(j)*a(k);
        elseif(A_(k,j)==1&&A_(k,i)~=1&&k~=j)
            Q_(j,k)=temp(k)-2*a(i)*a(k);
            Q_(k,j)=temp(k)-2*a(i)*a(k);
        end
    end
    a(j)=a(j)+a(i);
    a(i)=0;
    Q=Q+Q_(i,j);
    for m=1:N
        if(A_(m,i)==1)
            A_(m,i)=0;
            A_(m,j)=1;
            A_(i,m)=0;
            A_(j,m)=1;
        end
    end
end
end